// Syncs the web game into the Android project and builds the signed release .aab
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const and = path.join(root, 'android');
if (!fs.existsSync(and)) { console.error('android/ not found. Run: npm run android:setup'); process.exit(1); }
if (!fs.existsSync(path.join(and, 'keystore.properties'))) {
  console.error('Missing android/keystore.properties - the .aab would be UNSIGNED and Google Play would reject it.\nSee README.md, step 3.'); process.exit(1); }
const sh = process.platform === 'win32';
const run = (cmd, args, cwd) => { const r = spawnSync(cmd, args, { cwd, stdio: 'inherit', shell: sh }); if (r.status !== 0) process.exit(r.status || 1); };
run('npx', ['cap', 'sync', 'android'], root);
run(sh ? 'gradlew.bat' : './gradlew', ['clean', 'bundleRelease'], and);
const out = path.join(and, 'app', 'build', 'outputs', 'bundle', 'release', 'app-release.aab');
console.log(fs.existsSync(out) ? `\nSUCCESS -> ${out}` : '\nBuild finished but .aab not found at the expected path.');
