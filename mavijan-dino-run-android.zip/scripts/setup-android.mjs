// Creates the Capacitor Android project (if needed) and applies the game-specific native settings.
// Safe to re-run. Usage:  npm run android:setup
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
const run = (cmd, args) => {
  const r = spawnSync(cmd, args, { cwd: root, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) { console.error(`\nFAILED: ${cmd} ${args.join(' ')}`); process.exit(r.status || 1); }
};
const warn = (m) => console.warn('  [warn] ' + m);
const ok = (m) => console.log('  [ok] ' + m);
const and = path.join(root, 'android');
const main = path.join(and, 'app', 'src', 'main');
const ov = path.join(root, 'android-overrides');

if (!fs.existsSync(and)) run('npx', ['cap', 'add', 'android']);
else ok('android/ already exists - re-applying settings');
if (!process.env.SKIP_SYNC) run('npx', ['cap', 'sync', 'android']);

function patchFile(file, fn, label) {
  if (!fs.existsSync(file)) return warn(`${label}: file not found (${path.relative(root, file)})`);
  const before = fs.readFileSync(file, 'utf8'); const after = fn(before);
  if (after !== before) { fs.writeFileSync(file, after); ok(label); } else ok(label + ' (already applied)');
}

// 1. Manifest: landscape lock
patchFile(path.join(main, 'AndroidManifest.xml'), (s) => {
  if (!s.includes('screenOrientation')) s = s.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
  if (!s.includes('android:hardwareAccelerated')) s = s.replace('<application', '<application\n        android:hardwareAccelerated="true"');
  return s;
}, 'Manifest: landscape lock + hardware acceleration');

// 2. MainActivity: immersive fullscreen + WebView tuning
const pkgPath = path.join(main, 'java', ...cfg.appId.split('.'));
fs.mkdirSync(pkgPath, { recursive: true });
fs.writeFileSync(path.join(pkgPath, 'MainActivity.java'),
  fs.readFileSync(path.join(ov, 'MainActivity.java.tpl'), 'utf8').replace('__PACKAGE__', cfg.appId));
ok('MainActivity.java (immersive fullscreen, WebView tuning, audio autoplay)');

// 3. Icons (+ remove webp duplicates that would clash with our PNGs)
const res = path.join(main, 'res');
const copyDir = (src, dst) => { fs.mkdirSync(dst, { recursive: true }); for (const e of fs.readdirSync(src, { withFileTypes: true })) {
  const s = path.join(src, e.name), d = path.join(dst, e.name); e.isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d); } };
if (fs.existsSync(res)) {
  for (const d of fs.readdirSync(res)) if (d.startsWith('mipmap-')) for (const f of fs.readdirSync(path.join(res, d)))
    if (/^ic_launcher.*\.webp$/.test(f)) fs.unlinkSync(path.join(res, d, f));
  copyDir(path.join(ov, 'res'), res); ok('Launcher icons (adaptive + legacy)');
  // 4. Splash images
  let n = 0; const walk = (dir) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p); else if (e.name === 'splash.png') { fs.copyFileSync(path.join(ov, 'splash.png'), p); n++; } } };
  walk(res); fs.mkdirSync(path.join(res, 'drawable'), { recursive: true });
  if (!fs.existsSync(path.join(res, 'drawable', 'splash.png'))) { fs.copyFileSync(path.join(ov, 'splash.png'), path.join(res, 'drawable', 'splash.png')); n++; }
  ok(`Splash screen (${n} image file(s))`);
  // 5. Styles: splash background + fullscreen window
  patchFile(path.join(res, 'values', 'styles.xml'), (s) => {
    if (!s.includes('windowSplashScreenBackground')) s = s.replace(/(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/, '$1\n        <item name="windowSplashScreenBackground">#F7F7F7</item>');
    if (!s.includes('android:windowFullscreen')) s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowFullscreen">true</item>');
    return s; }, 'Styles: splash background + fullscreen window');
} else warn('res/ folder not found - was `npx cap add android` successful?');

// 6. Release signing hook (reads android/keystore.properties)
patchFile(path.join(and, 'app', 'build.gradle'), (s) => {
  if (s.includes('keystore.properties')) return s;
  s = s.replace(/^android\s*\{/m, `def keystorePropertiesFile = rootProject.file("keystore.properties")
def keystoreProperties = new Properties()
if (keystorePropertiesFile.exists()) { keystorePropertiesFile.withInputStream { keystoreProperties.load(it) } }

android {
    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile = rootProject.file(keystoreProperties['storeFile'])
                storePassword = keystoreProperties['storePassword']
                keyAlias = keystoreProperties['keyAlias']
                keyPassword = keystoreProperties['keyPassword']
            }
        }
    }`);
  s = s.replace(/(buildTypes\s*\{\s*release\s*\{)/, `$1
            if (keystorePropertiesFile.exists()) { signingConfig = signingConfigs.release }`);
  return s; }, 'app/build.gradle: release signing from keystore.properties');

console.log('\nDone. Next: create your keystore (see README.md), then run:  npm run android:aab');
