# Mavijan Dino Run - Android app (Capacitor 8)

The game lives in `www/index.html` (one self-contained file; both character sprites are embedded, no network needed).
Capacitor wraps it in a native Android app that runs fully offline.

- Package / application ID: **com.mavijan.dinorun**  (permanent once uploaded to Google Play - change it in `capacitor.config.json` BEFORE the first `android:setup` if you want another)
- App name: **Mavijan Dino Run**
- Output bundle: **android/app/build/outputs/bundle/release/app-release.aab**

## 0. Install once
- Node.js 22+  (`node -v`)
- JDK 21       (`java -version`)
- Android Studio (Otter 2025.2.1 or newer) -> SDK Manager: Android SDK Platform 36 + Build-Tools 36
- Set `ANDROID_HOME` (e.g. `~/Android/Sdk`, Windows: `%LOCALAPPDATA%\Android\Sdk`) and accept licences: `sdkmanager --licenses`

## 1. Create + configure the Android project
```
npm install
npm run android:setup
```
This runs `npx cap add android`, syncs `www/`, then applies: landscape lock (sensorLandscape), immersive fullscreen
(bars hidden, swipe shows them briefly), WebView tuning (no overscroll/zoom/long-press, audio autoplay allowed),
icons, splash screen, and release-signing hook.

## 2. Test on a phone before releasing
Enable USB debugging on the phone, plug it in, then:
```
npx cap run android
```

## 3. Create your upload key (once - keep it safe, back it up, never commit it)
```
keytool -genkeypair -v -storetype PKCS12 -keystore mavijan-upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
```
Create `android/keystore.properties`:
```
storeFile=../mavijan-upload.jks
storePassword=YOUR_STORE_PASSWORD
keyAlias=upload
keyPassword=YOUR_KEY_PASSWORD
```

## 4. Build the signed release bundle
```
npm run android:aab
```
(= `npx cap sync android` then `cd android && ./gradlew clean bundleRelease`; on Windows `gradlew.bat`)

## 5. Google Play
1. Play Console -> Create app -> upload `app-release.aab` (internal testing track first). Let Google manage app signing (Play App Signing); your key above is the *upload* key.
2. Fill in: store listing (icon `store-assets/play-icon-512.png`, feature graphic `store-assets/play-feature-1024x500.png`, 2+ phone screenshots), content rating, data safety (the app collects no data and makes no network calls), target audience, privacy policy URL.
3. To ship an update: raise `versionCode` (and `versionName`) in `android/app/build.gradle`, rebuild.

## Changing the game later
Edit `www/index.html`, then `npm run android:aab` (it re-syncs automatically).
